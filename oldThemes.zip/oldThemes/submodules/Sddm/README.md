# Theme_SDDM
## My SDDM Theme, Forked from [Solarize-sddm-theme](https://github.com/MalditoBarbudo/solarized_sddm_theme)

![screenshot](https://user-images.githubusercontent.com/104640155/225871881-53bacb4c-bf12-421f-b659-19e645743797.png)
