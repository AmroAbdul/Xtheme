# Darkula for [LaTeX](https://www.latex-project.org)

> A dark theme for [LaTeX](https://www.latex-project.org), forked from [draculatheme](https://draculatheme.com)

#![Screenshot](./screenshot.png)




